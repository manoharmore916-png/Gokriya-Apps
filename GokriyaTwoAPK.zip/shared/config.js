// Supabase URL आणि Key इथे भरली तरी चालते, किंवा app उघडल्यावर Setup screen मध्ये paste करा.
// Key = "anon public" किंवा "publishable" key (secret/service_role key कधीही टाकू नका).
window.GOKRIYA_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_KEY: ""
};

/* Gokriya shared API: plain fetch to Supabase REST (no extra libraries). */
(function () {
  var cfg = window.GOKRIYA_CONFIG || {};
  var STATUS = ['New', 'Accepted', 'Production', 'Ready', 'Dispatched'];
  var LABEL = {
    New: 'नवीन',
    Accepted: 'स्वीकारले',
    Production: 'उत्पादनात',
    Ready: 'तयार',
    Dispatched: 'Dispatch झाले'
  };

  function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  function getCfg() {
    var url = (ls('gk_url') || cfg.SUPABASE_URL || '').trim().replace(/\/rest\/v1.*$/, '').replace(/\/+$/, '');
    var key = (ls('gk_key') || cfg.SUPABASE_KEY || '').trim();
    return { url: url, key: key };
  }
  function saveCfg(url, key) { lsSet('gk_url', (url || '').trim()); lsSet('gk_key', (key || '').trim()); }
  function configured() {
    var c = getCfg();
    return /^https?:\/\/.+/.test(c.url) && c.key.length > 20;
  }

  async function req(path, opts) {
    opts = opts || {};
    var c = getCfg();
    if (!configured()) throw new Error('SETUP: Supabase URL / Key भरलेली नाही');
    var headers = { apikey: c.key, 'Content-Type': 'application/json' };
    // जुनी JWT key: Bearer पण लागते. नवीन sb_publishable_ key: फक्त apikey header.
    if (c.key.indexOf('sb_') !== 0) headers.Authorization = 'Bearer ' + c.key;
    if (opts.headers) for (var h in opts.headers) headers[h] = opts.headers[h];
    var res;
    try {
      res = await fetch(c.url + path, {
        method: opts.method || 'GET',
        headers: headers,
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined
      });
    } catch (e) {
      throw new Error('NETWORK: ' + (e && e.message ? e.message : e) + ' [' + c.url + ']');
    }
    var text = await res.text();
    var data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
    if (!res.ok) {
      var msg = (data && (data.message || data.hint || data.error_description || data.msg)) || text || ('status ' + res.status);
      var err = new Error('HTTP ' + res.status + ': ' + msg);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  /* ---------- App calls ---------- */
  function login(role, code, pin) {
    return req('/rest/v1/rpc/app_login', { method: 'POST', body: { p_role: role, p_code: code, p_pin: pin } });
  }
  function products() { return req('/rest/v1/products?active=eq.true&order=sort.asc,id.asc'); }
  function createOrder(row) {
    return req('/rest/v1/orders', { method: 'POST', body: row, headers: { Prefer: 'return=representation' } });
  }
  function myOrders(franchiseId) {
    return req('/rest/v1/orders?franchise_id=eq.' + encodeURIComponent(franchiseId) + '&order=created_at.desc&limit=100');
  }
  function allOrders() { return req('/rest/v1/orders?order=created_at.desc&limit=300'); }
  function setStatus(id, oldStatus, newStatus) {
    return req('/rest/v1/orders?id=eq.' + encodeURIComponent(id) + '&status=eq.' + encodeURIComponent(oldStatus), {
      method: 'PATCH',
      body: { status: newStatus, updated_at: new Date().toISOString() },
      headers: { Prefer: 'return=representation' }
    });
  }

  async function test() {
    var c = getCfg();
    var out = [];
    out.push('URL: ' + (c.url || '(रिकामा)'));
    out.push('Key: ' + (c.key ? c.key.slice(0, 14) + '… (' + c.key.length + ' अक्षरे)' : '(रिकामी)'));
    out.push('Phone online: ' + (navigator.onLine ? 'हो' : 'नाही'));
    out.push('Native HTTP: ' + ((window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) ? 'Android app' : 'browser'));
    if (!configured()) {
      out.push('\n❌ URL किंवा Key रिकामी/चुकीची आहे.');
      return out.join('\n');
    }
    try {
      var r = await req('/rest/v1/products?select=id&limit=1');
      out.push('\n✅ Supabase शी connect झालं. products table ओके (' + r.length + ' row).');
    } catch (e) {
      out.push('\n❌ ' + e.message);
      if (/^NETWORK/.test(e.message)) {
        out.push('→ URL चुकीचा, इंटरनेट बंद, किंवा Supabase project "paused" आहे (dashboard मध्ये Restore करा).');
      } else if (e.status === 401 || e.status === 403) {
        out.push('→ Key चुकीची आहे. Supabase > Project Settings > API मधली anon/publishable key वापरा.');
      } else if (e.status === 404) {
        out.push('→ Tables नाहीत. supabase.sql SQL Editor मध्ये Run करा.');
      }
    }
    return out.join('\n');
  }

  /* ---------- UI helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }
  function money(n) { return '₹' + (Math.round(Number(n || 0) * 100) / 100).toLocaleString('en-IN'); }
  function fmtDate(s) {
    try {
      return new Date(s).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
    } catch (e) { return s; }
  }
  function toast(msg) {
    var t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 3200);
  }
  function beep() {
    try {
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
      var A = window.AudioContext || window.webkitAudioContext;
      if (!A) return;
      var a = new A(), o = a.createOscillator(), g = a.createGain();
      o.connect(g); g.connect(a.destination);
      o.frequency.value = 880; g.gain.value = 0.15;
      o.start(); setTimeout(function () { o.stop(); a.close(); }, 350);
    } catch (e) {}
  }

  function setupScreen(root, onClose) {
    var c = getCfg();
    root.innerHTML =
      '<div class="screen"><div class="card">' +
      '<h2>Supabase Setup</h2>' +
      '<div class="mut">Supabase > Project Settings > API मधून Project URL आणि anon/publishable key इथे paste करा.</div>' +
      '<label>Project URL</label><input type="url" id="s-url" placeholder="https://xxxx.supabase.co" value="' + esc(c.url) + '">' +
      '<label>anon / publishable key</label><textarea id="s-key" placeholder="eyJ... किंवा sb_publishable_...">' + esc(c.key) + '</textarea>' +
      '<button class="btn" id="s-save">Save</button>' +
      '<button class="btn sec" id="s-test">Connection Test</button>' +
      (onClose ? '<button class="btn sec" id="s-back">← मागे</button>' : '') +
      '<pre id="s-out" style="display:none"></pre>' +
      '</div></div>';
    var $ = function (id) { return root.querySelector(id); };
    function readInputs() { saveCfg($('#s-url').value, $('#s-key').value); }
    $('#s-save').onclick = function () {
      readInputs();
      toast('Save झालं');
      if (onClose) onClose();
    };
    $('#s-test').onclick = async function () {
      readInputs();
      var out = $('#s-out');
      out.style.display = 'block';
      out.textContent = 'तपासत आहे…';
      out.textContent = await test();
    };
    if (onClose) $('#s-back').onclick = function () { readInputs(); onClose(); };
  }

  window.GK = {
    STATUS: STATUS, LABEL: LABEL,
    getCfg: getCfg, saveCfg: saveCfg, configured: configured, req: req, test: test,
    login: login, products: products, createOrder: createOrder, myOrders: myOrders, allOrders: allOrders, setStatus: setStatus,
    esc: esc, money: money, fmtDate: fmtDate, toast: toast, beep: beep, setupScreen: setupScreen
  };
})();
